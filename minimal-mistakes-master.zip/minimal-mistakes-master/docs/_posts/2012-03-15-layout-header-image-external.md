---
title: "Layout: Header Image (External URL)"
header:
  image: https://farm5.staticflickr.com/4140/4939863887_84705982fd_b.jpg
categories:
  - Layout
  - Uncategorized
tags:
  - edge case
  - featured image
  - image
  - layout
---

This post should display a **header image**, if the theme supports it.

Featured image is an external asset and should load.